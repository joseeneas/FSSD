// This function should retrieve all the project objects from projects array.
// It should then traverse over the array to create individual cards displaying each project details.
function loadProjects() {
  // Write your code here

}



// This function should return the projectId of the new project
function newProjectId(){
 // Write code to create and return new Project Id
}

function saveNewProject() {

  // Write your code here
  // Get the new project details by using the DOM elements
  
  // Create the new projectId by calling the newProjectId() function
  
  
  // Create a new project object
  

  // Add the new project object to the projects array 
  

  // Load the projects after adding the new project
  loadProjects();

  // Clear the values of the New Project Details Form after adding the new project
  document.getElementById("title").value = "";
  document.getElementById("desc").value = "";
  document.getElementById("image").value = "";
}
