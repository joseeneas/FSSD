// Question 1: Write a function that concatenates two strings using the `bind` method.


// Question 2: Create a function that counts the number of properties in an object using `apply` and the `arguments` object.


// Question 3: Write a function that accepts another function as an argument and returns a modified version of it that logs a message before and after executing the original function.

