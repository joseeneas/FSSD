// 1. Write a function `greet` that takes a name as a parameter and returns a greeting message.


// 2. Write a function `calculateArea` that takes the length and width of a rectangle as parameters and returns its area.


// 3. Write a function `isEven` that takes a number as a parameter and returns `true` if it is even, and `false` otherwise.


// 4. Write a function `calculateAverage` that takes an array of numbers as a parameter and returns the average of those numbers.


// 5. Implement a function that checks if a given number is a palindrome (e.g., 121, 1331).

