// 1. Declare a variable called `personName` and assign your name to it.


// 2. Create a variable `age` and assign your age to it.


// 3. Create a variable `isStudent` and assign it a boolean value.


// 4. Create a variable `favoriteFruits` and assign it an array of strings representing your favorite fruits.


// 5. Declare a variable `isSingleDigit` and assign it a boolean value based on the value of the given number, `num` if its less than 10


// 6. Create a variable `myNullValue` and assign it a null value.


// 8. Create a variable `undefinedVariable` and without assigning any value to it, display its value.


// 9. Declare a variable `yearsInCollege` and assign it a numeric value. Then, create a new variable `isInCollege` and assign it a boolean value based on whether `yearsInCollege` is greater than zero.


// 10. Create a variable `mixedArray` that contains a mix of data types, including numbers, strings, and booleans.

