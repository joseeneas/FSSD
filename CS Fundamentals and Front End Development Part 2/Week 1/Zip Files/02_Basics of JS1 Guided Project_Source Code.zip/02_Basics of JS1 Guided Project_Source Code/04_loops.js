// 1. Write a JavaScript program that prints the numbers from 1 to 10 using a for loop.


// 2. Write a JavaScript program that calculates the sum of all numbers from 1 to a given number using a while loop.


// 3. Write a JavaScript program that prints the even numbers from 1 to 20 using a do-while loop.


// 4. Write a JavaScript program that iterates through each number of an array using for..of loop and computes the sum of squares of each of these numbers.


// 5. Write a JavaScript program to iterate through the properties of the object using for...in loop.
