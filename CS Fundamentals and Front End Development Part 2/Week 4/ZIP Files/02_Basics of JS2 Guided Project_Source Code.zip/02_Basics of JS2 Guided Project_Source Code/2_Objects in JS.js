// Question 1: Declare an object named "person" with properties "name", "age", and "city" and set their respective values to "John", 30, and "New York".


// Question 2: Declare an object named "book" with properties "title", "author", and "year" and set their respective values to "The Great Gatsby", "F. Scott Fitzgerald", and 1925. Access the "author" property and store its value in a variable called "authorName".


// Question 3: Declare an object named "employee" with properties "name", "age", and "city". Delete the "city" property from the object.


// Question 4: Declare an object named "data" with a property named "key" having the value 123. Access the value of the "key" property using a variable called "value".

