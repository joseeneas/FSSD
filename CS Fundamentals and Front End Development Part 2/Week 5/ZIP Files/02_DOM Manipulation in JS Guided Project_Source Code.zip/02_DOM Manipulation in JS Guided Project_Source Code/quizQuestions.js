var questions = [
    {
        question: "What is the capital of France?",
        choices: ["Berlin", "Madrid", "Paris"],
        correctAnswer: 2
    },
    {
        question: "Which planet is known as the Red Planet?",
        choices: ["Mars", "Venus", "Jupiter"],
        correctAnswer: 0
    },
    {
        question: "How many continents are there on Earth?",
        choices: ["5", "6", "7"],
        correctAnswer: 2
    },
    {
        question: "Who wrote the play 'Romeo and Juliet'?",
        choices: ["Charles Dickens", "William Shakespeare", "Jane Austen"],
        correctAnswer: 1
    },
    {
        question: "What is the largest mammal in the world?",
        choices: ["Giraffe", "African Elephant", "Blue Whale"],
        correctAnswer: 2
    }
];